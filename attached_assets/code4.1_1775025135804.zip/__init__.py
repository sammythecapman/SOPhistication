"""
SharePoint integration package.

Usage:
    from sharepoint.factory import get_writer, get_reader, get_status
"""

from .factory import get_writer, get_reader, get_status

__all__ = ["get_writer", "get_reader", "get_status"]
