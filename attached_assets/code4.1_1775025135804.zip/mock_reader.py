"""
Mock SharePoint reader — browses and reads from the local mock library
that simulates a SharePoint Document Library.

Toggle with env var: SHAREPOINT_MODE=mock
"""

import json
import os
from pathlib import Path
from typing import List, Dict, Optional


_MOCK_ROOT = Path(__file__).parent.parent / "mock_sharepoint_library"


class MockSharePointReader:
    """Drop-in replacement for SharePointReader that reads from local JSON files."""

    def __init__(self):
        self.mock_root = _MOCK_ROOT

    @property
    def is_configured(self) -> bool:
        """Mock is always configured."""
        return True

    def list_folders(self, library_name: str = "Documents") -> List[Dict]:
        """
        List folders/files in the mock library root.
        Mirrors the real reader's return format.
        """
        root = self.mock_root
        if not root.exists():
            return []

        items = []
        for entry in sorted(root.iterdir()):
            # Skip metadata files
            if entry.name.startswith("_"):
                continue
            items.append({
                "id": entry.name,
                "name": entry.name,
                "type": "folder" if entry.is_dir() else "file",
                "size": entry.stat().st_size if entry.is_file() else 0,
                "modified": _isoformat(entry.stat().st_mtime),
                "download_url": f"file://{entry.resolve()}",
            })

        return items

    def list_pdfs_in_folder(self, folder_id: str) -> List[Dict]:
        """
        List PDF files in a specific folder.
        In mock mode, folder_id is the folder name.
        Also lists .json extraction files for convenience.
        """
        folder_path = self.mock_root / folder_id
        if not folder_path.exists():
            return []

        items = []
        for entry in sorted(folder_path.iterdir()):
            # Skip metadata sidecars
            if entry.name.endswith(".meta.json"):
                continue
            if entry.suffix.lower() in (".pdf", ".json"):
                items.append({
                    "id": entry.name,
                    "name": entry.name,
                    "size": entry.stat().st_size,
                    "modified": _isoformat(entry.stat().st_mtime),
                    "download_url": f"file://{entry.resolve()}",
                })

        return items

    def download_file(self, file_id: str, dest_path: str) -> str:
        """
        'Download' a file from the mock library to a local path.
        In mock mode, file_id can be a relative path within the mock root.
        """
        import shutil

        # Try to find the file in the mock root
        source = self.mock_root / file_id
        if not source.exists():
            # Search recursively
            for candidate in self.mock_root.rglob(file_id):
                source = candidate
                break

        if not source.exists():
            raise FileNotFoundError(f"File '{file_id}' not found in mock SharePoint library")

        shutil.copy2(str(source), dest_path)
        return dest_path

    def get_folder_metadata(self, folder_name: str) -> List[Dict]:
        """
        Utility: read all metadata sidecars in a folder.
        Returns the metadata for all pushed extractions.
        """
        folder_path = self.mock_root / folder_name
        if not folder_path.exists():
            return []

        results = []
        for meta_file in sorted(folder_path.glob("*.meta.json")):
            try:
                results.append(json.loads(meta_file.read_text()))
            except Exception:
                continue
        return results


def _isoformat(timestamp: float) -> str:
    """Convert a Unix timestamp to ISO format string."""
    from datetime import datetime
    return datetime.fromtimestamp(timestamp).isoformat()
