"""
SharePoint service factory.

Returns mock or real SharePoint reader/writer based on configuration.

Usage in app.py:
    from sharepoint.factory import get_writer, get_reader, get_status

Config:
    Set SHAREPOINT_MODE=mock to use local JSON storage (no credentials needed).
    When real credentials are set (SHAREPOINT_CLIENT_ID, etc.), it uses the real Graph API.
    If neither is configured, falls back to mock mode automatically.
"""

import os


def _is_mock_mode() -> bool:
    """Determine if we should use mock SharePoint."""
    # Explicit mock mode
    if os.environ.get("SHAREPOINT_MODE", "").lower() == "mock":
        return True
    # If no real credentials are configured, default to mock
    required = ["SHAREPOINT_CLIENT_ID", "SHAREPOINT_CLIENT_SECRET",
                "SHAREPOINT_TENANT_ID", "SHAREPOINT_SITE_URL"]
    if not all(os.environ.get(k) for k in required):
        return True
    return False


def get_writer():
    """Get the appropriate SharePoint writer instance."""
    if _is_mock_mode():
        from .mock_writer import MockSharePointWriter
        return MockSharePointWriter()
    else:
        from .writer import SharePointWriter
        return SharePointWriter()


def get_reader():
    """Get the appropriate SharePoint reader instance."""
    if _is_mock_mode():
        from .mock_reader import MockSharePointReader
        return MockSharePointReader()
    else:
        from .reader import SharePointReader
        return SharePointReader()


def get_status() -> dict:
    """Get the current SharePoint integration status."""
    mock = _is_mock_mode()
    if mock:
        return {
            "configured": True,
            "mode": "mock",
            "message": (
                "SharePoint running in MOCK mode — data is stored locally as JSON files. "
                "Set real SharePoint credentials to connect to your firm's SharePoint."
            ),
        }
    else:
        from .auth import SharePointAuth
        auth = SharePointAuth()
        return {
            "configured": auth.is_configured,
            "mode": "live",
            "message": "SharePoint integration ready" if auth.is_configured
            else "SharePoint credentials not configured.",
        }
