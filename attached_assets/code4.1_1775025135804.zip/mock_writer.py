"""
Mock SharePoint writer — stores extraction results locally in a folder structure
that simulates a SharePoint Document Library.

Structure:
  mock_sharepoint_library/
    ├── _list_items.json              ← simulates SharePoint List rows
    └── SBA Extractions/
        ├── SBA_Extraction_BorrowerName_20250401_120000.json
        └── ...

Toggle with env var: SHAREPOINT_MODE=mock
"""

import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any


# Root of the mock SharePoint file system
_MOCK_ROOT = Path(__file__).parent.parent / "mock_sharepoint_library"


class MockSharePointWriter:
    """Drop-in replacement for SharePointWriter that writes to local JSON files."""

    def __init__(self):
        self.mock_root = _MOCK_ROOT
        self.list_name = os.environ.get("SHAREPOINT_LIST_NAME", "SBA Extractions")
        self.mock_root.mkdir(parents=True, exist_ok=True)

    @property
    def is_configured(self) -> bool:
        """Mock is always configured — no credentials needed."""
        return True

    def push_to_list(self, extraction_data: Dict[str, Any]) -> Dict:
        """
        Simulate pushing a row to a SharePoint List.
        Appends to a local JSON file that acts as the list store.
        """
        formatted = extraction_data.get("formatted_data", {})
        deal = extraction_data.get("deal_structure", {})
        summary = extraction_data.get("summary", {})

        # Build the same fields the real writer would send
        fields = {
            "Title": formatted.get("Borrower1Name", "Unknown Borrower"),
            "DealType": deal.get("deal_type", ""),
            "LoanProgram": deal.get("loan_program", ""),
            "LoanAmount": formatted.get("LoanAmountShort", ""),
            "MaturityDate": formatted.get("MaturityDate", ""),
            "LenderName": formatted.get("LenderName", ""),
            "BorrowerName": formatted.get("Borrower1Name", ""),
            "SBALoanNumber": formatted.get("SBALoanNumber", ""),
            "CompletionPct": str(summary.get("completion_percentage", 0)),
            "TermsFilename": extraction_data.get("terms_filename", ""),
        }

        # Add remaining formatted fields (mirrors real writer behavior)
        for k, v in formatted.items():
            if k not in fields and v:
                safe_key = k.replace("/", "_").replace(" ", "_")
                fields[safe_key] = str(v)[:255]

        # Create a mock list item with a fake SharePoint ID
        item_id = str(uuid.uuid4())[:8]
        list_item = {
            "id": item_id,
            "createdDateTime": datetime.now().isoformat(),
            "fields": fields,
        }

        # Append to the list store file
        list_file = self.mock_root / "_list_items.json"
        existing = []
        if list_file.exists():
            try:
                existing = json.loads(list_file.read_text())
            except (json.JSONDecodeError, Exception):
                existing = []

        existing.append(list_item)
        list_file.write_text(json.dumps(existing, indent=2))

        print(f"📋 [MOCK SP] Added list item '{fields['Title']}' (id={item_id})")
        return list_item

    def push_to_folder(self, extraction_data: Dict[str, Any],
                       folder_name: str = "SBA Extractions") -> Dict:
        """
        Simulate uploading a JSON file to a SharePoint Document Library folder.
        Creates a local file in the mock library structure.
        """
        formatted = extraction_data.get("formatted_data", {})
        borrower = formatted.get("Borrower1Name", "Unknown").replace(" ", "_")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"SBA_Extraction_{borrower}_{timestamp}.json"

        # Create the folder structure
        folder_path = self.mock_root / folder_name
        folder_path.mkdir(parents=True, exist_ok=True)

        # Write the extraction JSON (same content the real writer uploads)
        file_path = folder_path / filename
        json_content = json.dumps(formatted, indent=2)
        file_path.write_text(json_content)

        # Create a metadata sidecar (simulates SP metadata columns on the file)
        meta = {
            "id": str(uuid.uuid4())[:8],
            "name": filename,
            "size": len(json_content.encode("utf-8")),
            "createdDateTime": datetime.now().isoformat(),
            "lastModifiedDateTime": datetime.now().isoformat(),
            "webUrl": f"https://mock-sharepoint.local/sites/JBL/{folder_name}/{filename}",
            "folder_metadata": {
                "BorrowerName": formatted.get("Borrower1Name", ""),
                "SBALoanNumber": formatted.get("SBALoanNumber", ""),
                "DealType": extraction_data.get("deal_structure", {}).get("deal_type", ""),
                "LoanProgram": extraction_data.get("deal_structure", {}).get("loan_program", ""),
                "LoanAmount": formatted.get("LoanAmountShort", ""),
                "CompletionPct": extraction_data.get("summary", {}).get("completion_percentage", 0),
            },
        }
        meta_path = folder_path / f"{filename}.meta.json"
        meta_path.write_text(json.dumps(meta, indent=2))

        print(f"📁 [MOCK SP] Uploaded '{filename}' to /{folder_name}/")
        return {"filename": filename, "item": meta}

    def list_pushed_items(self) -> list:
        """Utility: read all items from the mock list store."""
        list_file = self.mock_root / "_list_items.json"
        if not list_file.exists():
            return []
        try:
            return json.loads(list_file.read_text())
        except Exception:
            return []
