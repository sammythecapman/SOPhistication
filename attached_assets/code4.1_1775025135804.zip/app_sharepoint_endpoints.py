"""
UPDATED SHAREPOINT ENDPOINTS for app.py
========================================
Replace the existing SharePoint section in your app.py with this code.
The only changes are swapping direct class imports for the factory functions.
"""

# ──────────────────────────────────────────────
# SharePoint endpoints (mock + live via factory)
# ──────────────────────────────────────────────

@app.route("/api/sharepoint/status")
def sharepoint_status():
    from sharepoint.factory import get_status
    return jsonify(get_status())


@app.route("/api/sharepoint/push/<int:extraction_id>", methods=["POST"])
def push_to_sharepoint(extraction_id: int):
    from sharepoint.factory import get_writer

    writer = get_writer()
    if not writer.is_configured:
        return jsonify({"error": "SharePoint is not configured"}), 503

    try:
        extraction = db.get_extraction(extraction_id)
        if not extraction:
            return jsonify({"error": "Extraction not found"}), 404

        target = request.json.get("target", "folder")  # "folder" or "list"

        if target == "list":
            result = writer.push_to_list(extraction)
        else:
            result = writer.push_to_folder(extraction)

        return jsonify({"message": "Successfully pushed to SharePoint", "result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/sharepoint/browse")
def browse_sharepoint():
    """Browse folders and files in the SharePoint document library."""
    from sharepoint.factory import get_reader

    reader = get_reader()
    if not reader.is_configured:
        return jsonify({"error": "SharePoint is not configured"}), 503

    folder_id = request.args.get("folder_id")
    try:
        if folder_id:
            items = reader.list_pdfs_in_folder(folder_id)
        else:
            items = reader.list_folders()
        return jsonify({"items": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/sharepoint/list-items")
def list_sharepoint_items():
    """View all items pushed to the SharePoint list (mock mode only)."""
    from sharepoint.factory import get_writer, get_status

    status = get_status()
    if status["mode"] != "mock":
        return jsonify({"error": "This endpoint is only available in mock mode"}), 400

    writer = get_writer()
    items = writer.list_pushed_items() if hasattr(writer, "list_pushed_items") else []
    return jsonify({"items": items, "count": len(items)})
